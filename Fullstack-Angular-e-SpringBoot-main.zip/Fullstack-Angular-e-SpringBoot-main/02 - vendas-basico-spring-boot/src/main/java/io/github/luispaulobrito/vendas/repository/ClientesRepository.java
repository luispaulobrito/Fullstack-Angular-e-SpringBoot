package io.github.luispaulobrito.vendas.repository;

import io.github.luispaulobrito.vendas.model.Cliente;
import org.springframework.stereotype.Repository;

@Repository
public class ClientesRepository {
    public void persistir(Cliente cliente) {
        //acessa a base e salva o cliente
    }
}
