package io.github.luispaulobrito.vendas;

public interface Animal {
    void fazerBarulho();
}
