import { Cliente } from './../../clientes/cliente';
export class ServicoPrestadoBusca {
  descricao: string;
  valor: number;
  data: string;
  cliente: Cliente;
}
