export class ServicoPrestado {
  descricao: string;
  preco: string;
  data: string;
  idCliente: number;
}
