export const environment = {
  production: false,
  apiURLBase: 'http://localhost:8080'
};
