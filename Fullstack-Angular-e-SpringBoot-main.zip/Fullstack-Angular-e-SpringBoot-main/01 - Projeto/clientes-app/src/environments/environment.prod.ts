export const environment = {
  production: true,
  // adicione quaisquer outras configurações de ambiente que desejar aqui
};
